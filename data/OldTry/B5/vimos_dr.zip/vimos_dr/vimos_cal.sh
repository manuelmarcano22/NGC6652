#!/bin/sh


python vimos_red.py

cd q1/
python vimos_bias.py
esorex vmbias --Stackmethod=Average bias.sof

python vimos_calib.py
esorex vmifucalib calib.sof

python ifustandard.py
esorex vmifustandard ifustandard.sof

python ifuscience.py
esorex vmifuscience --CalibrateFlux=true ifuscience.sof

