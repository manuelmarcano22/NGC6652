from astropy.io import fits
import glob, os



files = glob.glob('*fits.fz')

flat = []
for f in files:
    hd = fits.getheader(f)
    if hd['ESO DPR TYPE']=='FLAT,LAMP':
            flat.append(f)

arc = []
for f in files:
    hd = fits.getheader(f)
    if hd['ESO DPR TYPE']=='WAVE,LAMP':
            arc.append(f)

sof = open('calib.sof', 'w')        
for i in flat:
    sof.write('./'+str(i)+'\tIFU_SCREEN_FLAT\n')

        
for i in arc:
    sof.write('./'+str(i)+'\tIFU_ARC_SPECTRUM\n')


sof.write('master_bias.fits\tMASTER_BIAS\n')
sof.write('/path/to/vimos/cal/lcat_HR_red.fits\tLINE_CATALOG\n')
sof.write('/path/to/vimos/cal/ifu_ident_HR_red.1.fits\tIFU_IDENT\n')

sof.close()