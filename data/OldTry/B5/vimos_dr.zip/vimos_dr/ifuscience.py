from astropy.io import fits
import glob, os



files = glob.glob('*fits.fz')

obj = []
for f in files:
    hd = fits.getheader(f)
    if hd['ESO DPR TYPE']=='OBJECT':
            obj.append(f)


sof = open('ifuscience.sof', 'w')

for i in obj:
    sof.write('./'+str(i)+'\tIFU_SCIENCE\n')


sof.write('master_bias.fits\tMASTER_BIAS\n')
sof.write('ifu_ids.fits\tIFU_IDS\n')
sof.write('ifu_trace.fits\tIFU_TRACE\n')
sof.write('ifu_tansmission.fits\tIFU_TRANSMISSION\n')
sof.write('/path/to/vimos/cal/extinct_table.fits\tEXTINCT_TABLE\n')
sof.write('ifu_specphot_table.fits\tIFU_SPECPHOT_TABLE\n')

sof.close()