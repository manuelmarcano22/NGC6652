from astropy.io import fits
import glob, os



files = glob.glob('*fits.fz')

std = []
for f in files:
    hd = fits.getheader(f)
    if hd['ESO DPR TYPE']=='STD':
            std.append(f)


sof = open('ifustandard.sof', 'w')

for i in std:
    sof.write('./'+str(i)+'\tIFU_STANDARD\n')


sof.write('master_bias.fits\tMASTER_BIAS\n')
sof.write('ifu_ids.fits\tIFU_IDS\n')
sof.write('ifu_trace.fits\tIFU_TRACE\n')
sof.write('ifu_tansmission.fits\tIFU_TRANSMISSION\n')
sof.write('/path/to/vimos/cal/extinct_table.fits\tEXTINCT_TABLE\n')
sof.write('/path/to/vimos/cal/ltt4816.tfits\tSTD_FLUX_TABLE\n')

sof.close()